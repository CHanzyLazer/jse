# https://github.com/pypa/setuptools/issues/2928
from distutils.command.build import build

class jep_build(build):
    sub_commands = build.sub_commands
