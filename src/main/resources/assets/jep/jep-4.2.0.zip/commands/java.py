try:
    from setuptools.modified import newer_group
except ImportError:
    from setuptools.dep_util import newer_group

import fnmatch
import os
import traceback

from commands.util import CommandFailed
from commands.util import configure_error
from commands.util import is_osx
from commands.util import is_windows
from commands.util import shell

_java_home = None


def get_java_home():
    global _java_home
    if _java_home is not None:
        return _java_home

    env_home = os.environ.get('JAVA_HOME')
    if env_home:
        if is_windows():
           # remove quotes from each end if necessary
            env_home = env_home.strip('"')
        if os.path.exists(env_home):
            _java_home = env_home
            return env_home
        else:
            configure_error('Path ' + env_home +
                            ' indicated by JAVA_HOME does not exist.')

    if is_osx():
        # newer macs have an executable to help us
        try:
            result = shell('/usr/libexec/java_home')
            _java_home = result.stdout.decode('utf-8')
            return _java_home
        except CommandFailed:
            traceback.print_exc()

    configure_error(
        'Please set the environment variable JAVA_HOME to a path containing the JDK.')


def get_java_include():
    """
    Locate the Java include folders for compiling JNI applications.
    """
    inc_name = 'include'
    inc = os.path.join(get_java_home(), inc_name)
    if not os.path.exists(inc):
        configure_error("Include folder should be at '{0}' but doesn't exist. "
                        "Please check you've installed the JDK properly.".format(inc))
    jni = os.path.join(inc, "jni.h")
    if not os.path.exists(jni):
        configure_error("jni.h should be in '{0}' but doesn't exist. "
                        "Please check you've installed the JDK properly.".format(jni))

    paths = [inc]

    # Include platform specific headers if found
    include_linux = os.path.join(inc, 'linux')
    if os.path.exists(include_linux):
        paths.append(include_linux)

    include_darwin = os.path.join(inc, 'darwin')
    if os.path.exists(include_darwin):
        paths.append(include_darwin)

    include_win32 = os.path.join(inc, 'win32')
    if os.path.exists(include_win32):
        paths.append(include_win32)

    include_bsd = os.path.join(inc, 'freebsd')
    if os.path.exists(include_bsd):
        paths.append(include_bsd)
    return paths


def get_java_lib():
    lib_name = 'lib'
    lib = os.path.join(get_java_home(), lib_name)
    if not os.path.exists(lib):
        configure_error("Lib folder should be at '{0}' but doesn't exist. "
                        "Please check you've installed the JDK properly.".format(lib))
    return lib


def get_java_libraries():
    if not is_osx():
        return ['jvm']
    return []


def get_java_lib_folders():
    if not is_osx():
        if is_windows():
            jre = os.path.join(get_java_home(), 'lib')
        else:
            jre = os.path.join(get_java_home(), 'jre', 'lib')
            if not os.path.exists(jre):
                jre = os.path.join(get_java_home(), 'lib')
        folders = []
        for root, dirnames, filenames in os.walk(jre):
            if is_windows():
                for filename in fnmatch.filter(filenames, '*jvm.lib'):
                    folders.append(os.path.join(
                        root, os.path.dirname(filename)))
            else:
                for filename in fnmatch.filter(filenames, '*jvm.so'):
                    folders.append(os.path.join(
                        root, os.path.dirname(filename)))

        return list(set(folders))
    return []


def get_java_linker_args():
    return []


